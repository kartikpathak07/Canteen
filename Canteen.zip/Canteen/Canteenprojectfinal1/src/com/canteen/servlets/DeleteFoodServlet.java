package com.canteen.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.canteen.dao.impl.FoodDAOImpl;
import com.canteen.daos.FoodDAO;
import com.canteen.models.Food;


public class DeleteFoodServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private FoodDAO foodDao;
	
	public void init(ServletConfig config) throws ServletException {
		foodDao=new FoodDAOImpl();
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String foodID=request.getParameter("foodID");
		boolean isremoved=foodDao.removeFood(foodID);
		if(isremoved){
			RequestDispatcher rd=request.getRequestDispatcher("/MsgD.jsp");
			rd.forward(request, response);
			
		}
		else{
			response.sendRedirect("http://localhost:7001/Canteenproject/errorpage.html");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
