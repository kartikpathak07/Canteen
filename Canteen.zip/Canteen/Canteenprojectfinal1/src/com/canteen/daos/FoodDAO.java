package com.canteen.daos;

import java.sql.Connection;
import java.util.List;

import com.canteen.models.Food;

public interface FoodDAO {

	
	public Connection getConnection();
	public void closeConnection();
	public boolean addFood(Food food);
	public boolean removeFood(String foodID);
	public boolean updateFood(Food food);
	public List<Food> getAllFoodByVendorName(String vendor_name);
	public List<Food> getAllFood();
	
}
