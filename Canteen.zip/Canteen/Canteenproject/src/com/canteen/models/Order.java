package com.canteen.models;

import java.util.Date;

public class Order {

	private String order_Id;
	private int costPerItem;
	private int quant;
	private String userName;
	private Date dateOfOrder;
	public Order() {
		super();
		
	}
	public Order(String order_Id, int costPerItem, int quant,
			String userName,Date dateOfOrder) {
		super();
		this.order_Id = order_Id;
		this.costPerItem = costPerItem;
		this.quant = quant;
		this.userName = userName;
		this.dateOfOrder = dateOfOrder;
	}
	public String getOrder_Id() {
		return order_Id;
	}
	public void setOrder_Id(String order_Id) {
		this.order_Id = order_Id;
	}
	public int getCostPerItem() {
		return costPerItem;
	}
	public void setCostPerItem(int costPerItem) {
		this.costPerItem = costPerItem;
	}
	public int getQuant() {
		return quant;
	}
	public void setQuant(int quant) {
		this.quant = quant;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Date getDateOfOrder() {
		return dateOfOrder;
	}
	public void setDateOfOrder(Date dateOfOrder) {
		this.dateOfOrder = dateOfOrder;
	}
	
	
}
