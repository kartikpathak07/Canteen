package com.canteen.models;

public class Food {
	
	
	public String foodID;
	public String item_Name;
	public int item_Price;
	public String category;
	public Food() {
		super();
		
	}
	
	public String getFoodID() {
		return foodID;
	}
	public void setFoodID(String foodID) {
		this.foodID = foodID;
	}
	public String getItem_Name() {
		return item_Name;
	}
	public void setItem_Name(String item_Name) {
		this.item_Name = item_Name;
	}
	public int getItem_Price() {
		return item_Price;
	}
	public void setItem_Price(int item_Price) {
		this.item_Price = item_Price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	
	
}	