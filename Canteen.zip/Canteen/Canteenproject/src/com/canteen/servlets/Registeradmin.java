package com.canteen.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.canteen.dao.impl.AdminDAOImpl;
import com.canteen.daos.AdminDAO;
import com.canteen.models.Admin;


public class Registeradmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private AdminDAO adminDao;
	private ServletContext ctx;
	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("+++++ Init() Invoked +++++");
		adminDao=new AdminDAOImpl();
		ctx=config.getServletContext();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("+++++ doGet() Invoked++++");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String commonMsg=ctx.getInitParameter("commonMsg");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("LastName");
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String cellNo=request.getParameter("cellNo");
		String email=request.getParameter("email");
		
		Admin admin=new Admin(firstName, lastName, userName, password, cellNo, email);
		boolean isAdded=adminDao.addAdmin(admin);
		if(isAdded){
			out.println("<body bgcolor='pink'>");
			out.println("<center>");
			out.println("<h1>"+commonMsg+"</h1>");
			out.println("<h3>Successfully Registered Admin <I>"+userName+"</I></h3>");
			out.println("<h3><A href='homepage.jsp'>Login Now </A></h3>");
			out.println("</center>");
			out.println("</body>");
		}
		else
		{
			out.println("<body bgcolor='pink'>");
			out.println("<center>");
			out.println("<h1>"+commonMsg+"</h1>");//in order to change msg,change it in web.xml
			out.println("<h3>Error Registering Admin <I>"+userName+"</I></h3>");
			out.println("<h3><A href='homepage.jsp'>Register Again !! </A></h3>");
			out.println("</center>");
			out.println("</body>");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("++++doPost() Invoked ++++");
		doGet(request,response);
	}

}
