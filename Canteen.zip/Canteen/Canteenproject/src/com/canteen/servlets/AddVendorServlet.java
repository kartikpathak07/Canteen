package com.canteen.servlets;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.canteen.dao.impl.VendorDAOImpl;
import com.canteen.daos.VendorDAO;


public class AddVendorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private VendorDAO vendorDao;
	private ServletContext ctx;
	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("++++++ init() Invoked +++++");
		vendorDao=new VendorDAOImpl();
		ctx=config.getServletContext();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String cellNo=request.getParameter("cellNo");
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
