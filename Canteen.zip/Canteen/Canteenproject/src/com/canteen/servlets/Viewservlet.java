package com.canteen.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.canteen.dao.impl.VendorDAOImpl;
import com.canteen.daos.VendorDAO;
import com.canteen.models.Vendor;


public class Viewservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private VendorDAO vendorDao;
	private ServletContext ctx;
	
	
	public void init(ServletConfig config) throws ServletException {
		vendorDao=new VendorDAOImpl();
		ctx=config.getServletContext();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("++++ doGet() ++++");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		vendorDao=new VendorDAOImpl();
		
		ArrayList<Vendor> vendorList=new ArrayList<Vendor>();
		
		vendorList=(ArrayList<Vendor>) vendorDao.getAllVendors();
		String commonMsg=ctx.getInitParameter("commonMsg");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("++++doPost() ++++");
		this.doGet(request, response);
	}

}
