package com.canteen.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.canteen.dao.impl.UserDAOImpl;
import com.canteen.daos.AdminDAO;
import com.canteen.daos.UserDAO;
import com.canteen.daos.VendorDAO;
import com.canteen.models.Admin;
import com.canteen.models.User;
import com.canteen.models.Vendor;


public class LoginServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private UserDAO userDao;
	private AdminDAO adminDao;
	private VendorDAO vendorDao;
	
	public void init(ServletConfig config) throws ServletException {
		String driverClass=config.getInitParameter("driverClassName");
		String conURL=config.getInitParameter("conURL");
		String dbUserName=config.getInitParameter("dbUserName");
		String dbPassword=config.getInitParameter("dbPassword");
		userDao=(UserDAO) new UserDAOImpl(conURL, dbUserName, dbPassword, driverClass);
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		session.getMaxInactiveInterval();
		System.out.println("SESSION ID : :" +session.getId());
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String choice=request.getParameter("choice");
		if(choice.equals("Admin")){
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			
			Admin admin=new Admin();
			admin.setUserName(userName);
			admin.setPassword(password);
			
			boolean isValid=adminDao.validateAdmin(admin);
			if(isValid){
				out.println("<h4>Admin Working</h4>");
				session.setAttribute("sessAdmin", "admin");
				RequestDispatcher rd=request.getRequestDispatcher("/GetDetails1");
				rd.forward(request, response);
			}else
			{
				response.sendRedirect("http://localhost:7001/Canteenproject/invaliduser.html");
				
			}
		}
		else if(choice.equals("Vendor")){
			
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			
			Vendor vendor=new Vendor();
			vendor.setUserName(userName);
			vendor.setPassword(password);
			
			boolean isValid=vendorDao.validateVendor(vendor);
			if(isValid){
			out.println("<h4>Vendor Working</h4>");
			session.setAttribute("sessVendor", "vendor");
			RequestDispatcher rd=request.getRequestDispatcher("/GetDetails2");
			rd.forward(request, response);
		}else
		{
			response.sendRedirect("http://localhost:7001/Canteenproject/invaliduser.html");
			
		}
	}
		else {
			
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			
			User user=new User();
			user.setUserName(userName);
			user.setPassword(password);
			
			boolean isValid=userDao.validateUser(user);
			if(isValid){
			out.println("<h4>User Working</h4>");
			session.setAttribute("sessUser", "user");
			RequestDispatcher rd=request.getRequestDispatcher("/GetDetails3");
			rd.forward(request, response);
		}else
		{
			response.sendRedirect("http://localhost:7001/Canteenproject/invaliduser.html");
		}
	}	

		
		
}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
