package com.canteen.test;

import com.canteen.dao.impl.UserDAOImpl;
import com.canteen.models.User;

public class Testjdbc {

		public static void main(String[] args) {
			UserDAOImpl userDao =new UserDAOImpl();
			//User user=new User();
			User user=new User("Vaishali","Jain","vaishali124@abc.com","vaishali1234"
					,"9911111111","vaishali124@abc.com",40);
			
	}

}
