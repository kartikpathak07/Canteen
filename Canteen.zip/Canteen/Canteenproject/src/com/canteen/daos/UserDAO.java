package com.canteen.daos;

import java.sql.Connection;
import java.util.List;

import com.canteen.models.User;

public interface UserDAO {

	public Connection getConnection();
	public void closeConnection();
	public boolean addUser(User user);
	public boolean updateUser(User user);
	public boolean removeUser(String userId);
	public User getUser(String userName);
	public List<User> getAllUsers();
	public boolean validateUser(User user);
	public void getAllUsersForDBTraverse();
	public void getDBInfo();

}
