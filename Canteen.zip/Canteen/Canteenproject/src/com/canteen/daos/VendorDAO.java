package com.canteen.daos;

import java.sql.Connection;
import java.util.List;
import com.canteen.models.Vendor;

public interface VendorDAO {

	public Connection getConnection();
	public void closeConnection();
	public boolean addVendor(Vendor vendor);
	public boolean updateVendor(Vendor vendor);
	public boolean removeVendor(String userName);
	public Vendor getVendor(String userName);
	public List<Vendor> getAllVendors();
	public boolean validateVendor(Vendor vendor);
	
	
	
}
