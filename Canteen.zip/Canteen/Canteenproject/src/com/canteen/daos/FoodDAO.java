package com.canteen.daos;

import java.sql.Connection;

import com.canteen.models.Food;

public interface FoodDAO {

	
	public Connection getConnection();
	public void closeConnection();
	public boolean addFood(Food food);
	public boolean removeFood(int foodID);
	public boolean updateFood(Food food);
	
}
