package com.canteen.daos;



import java.sql.Connection;


import com.canteen.models.Order;

public interface OrderDAO {

	public Connection getConnection();
	public void closeConnection();
	public boolean addOrder(Order order);
	public boolean removeOrder(String order_Id);
	
}
