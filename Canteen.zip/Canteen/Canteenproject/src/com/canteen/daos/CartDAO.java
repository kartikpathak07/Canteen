package com.canteen.daos;

import java.sql.Connection;
import java.util.List;

import com.canteen.models.Food;

public interface CartDAO {

	public Connection getConnection();
	public void closeConnection();
	public boolean addFood(Food food);
	public boolean removeFood(int foodID);
	public List<Food> getAllFood();
}
