package com.canteen.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.canteen.models.Order;

public class OrderDAOImpl {

		private Connection con;
		private String conURL="jdbc:oracle:thin:@localhost:1521:XE";
		private String dbUserName="system";
		private String dbPassword="system";
		private String driverClass="oracle.jdbc.OracleDriver";
		
		
		
		public OrderDAOImpl() {
			
			try {
				Class.forName(driverClass);
				System.out.println("++++++DRIVER LOADED +++++++++");
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			}
			
			
		}
		public OrderDAOImpl(String conURL,String dbUserName,String dbPassword,String driverClass){
			this.conURL=conURL;
			this.dbUserName=dbUserName;
			this.dbPassword=dbPassword;
			this.driverClass=driverClass;
			
				try {
					Class.forName(this.driverClass);
				} catch (ClassNotFoundException e) {
					
					e.printStackTrace();
				}
				System.out.println("++++++++ DRIVER LOADED +++++");
			}
			
		
		public Connection getConnection() {
			
			try {
				con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
				System.out.println("++++++++ CONNECTION TO DB +++++++++");
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			return con;
		}
	
		
		public void closeConnection() {
			if(con!=null){
				try {
					con.close();
					System.out.println("++++++ CONNECTION TO DB CLOSED ++++++");
				} catch (SQLException e) {
					e.printStackTrace();
				}finally{
					closeConnection();
				}
			}
		}

	public boolean addOrder(Order order) {
		String SQL="insert into order_tbl values(?,?,?,?,?)";
		boolean isAdded=false;
		getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, order.getOrder_Id());
			ps.setInt(2, order.getCostPerItem());
			ps.setInt(3, order.getQuant());
			ps.setString(4,order.getUserName());
			ps.setDate(5,(Date) order.getDateOfOrder());
			
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isAdded=true;
				System.out.println("++++++++ ORDER ADDED SUCCESSFULLY +++++++");
				
			}
		
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isAdded;
	}

	
	public boolean removeOrder(String order_Id) {
		String SQL="delete from order_tbl where order_Id=?";
		boolean isRemoved=false;
		getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1,order_Id); //here only username is passed so not to use user.
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isRemoved=true;
				System.out.println("++++++ ORDER DELETED SUCCESSFULLY ++++++");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isRemoved;
	
	
	}

}
