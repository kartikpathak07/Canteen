package com.canteen.dao.impl;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.canteen.daos.AdminDAO;
import com.canteen.models.Admin;
import com.canteen.models.User;

public class AdminDAOImpl implements AdminDAO {
	
	private Connection con;
	private String conURL="jdbc:oracle:thin:@localhost:1521:XE";
	private String dbUserName="system";
	private String dbPassword="system";
	private String driverClass="oracle.jdbc.OracleDriver";
	
	
	
	public AdminDAOImpl() {
		
		try {
			Class.forName(driverClass);
			System.out.println("++++++DRIVER LOADED +++++++++");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
		
	}
	public AdminDAOImpl(String conURL,String dbUserName,String dbPassword,String driverClass){
		this.conURL=conURL;
		this.dbUserName=dbUserName;
		this.dbPassword=dbPassword;
		this.driverClass=driverClass;
		
			try {
				Class.forName(this.driverClass);
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			}
			System.out.println("++++++++ DRIVER LOADED +++++");
		}
		
	
	public Connection getConnection() {
		
		try {
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("++++++++ CONNECTION TO DB +++++++++");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return con;
	}

	
	public void closeConnection() {
		if(con!=null){
			try {
				con.close();
				System.out.println("++++++ CONNECTION TO DB CLOSED ++++++");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	
	public boolean addAdmin(Admin admin) {
		String SQL="insert into admin_tbl values(?,?,?,?,?,?)";
		boolean isAdded=false;
		getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, admin.getFirstName());
			ps.setString(2, admin.getLastName());
			ps.setString(3, admin.getUserName());
			ps.setString(4, admin.getPassword());
			ps.setString(5,admin.getCellNo());
			ps.setString(6, admin.getEmail());
			
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isAdded=true;
				System.out.println("++++++++ ADMIN ADDED SUCCESSFULLY +++++++");
				
			}
		
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isAdded;
	}


	public boolean updateAdmin(Admin admin) {
		String SQL="update admin_tbl set firstname=?,"
				+ "lastname=?,password=?,"
				+ "cellno=?,email=?"
				+ " where username=?";
		boolean isUpdated=false;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, admin.getFirstName());
			ps.setString(2, admin.getLastName());
			ps.setString(3, admin.getPassword());
			ps.setString(4, admin.getCellNo());
			ps.setString(5, admin.getEmail());
			
			ps.setString(6, admin.getUserName());
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isUpdated=true;
				System.out.println("++++++++  ADMIN UPDATED SUCCESSFULLY ++++++");
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isUpdated;
	}

	
	public boolean removeAdmin(String adminName) {
		
		String SQL="delete from admin_tbl where username=?";
		boolean isRemoved=false;
		getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1,adminName); //here only username is passed so not to use user.
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isRemoved=true;
				System.out.println("++++++ ADMIN DELETED SUCCESSFULLY ++++++");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isRemoved;
	}

	
	public Admin getAdmin(String adminName) {
		String SQL="select * from admin_tbl where username=?";
		Admin admin=null;
		getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, adminName);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				admin=new Admin();
				admin.setFirstName(rs.getString("firstname"));
				admin.setLastName(rs.getString("lastname"));
				admin.setUserName(rs.getString("username"));
				admin.setPassword(rs.getString("password"));
				admin.setCellNo(rs.getString("cellno"));
				admin.setEmail(rs.getString("email"));
				
	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		
		return admin;
	}
	public boolean validateAdmin(Admin admin) {
		String SQL="select * from admin_tbl where username=? and password=?";
		boolean isValid=false;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, admin.getUserName());
			ps.setString(2, admin.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				isValid=true;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return isValid;
	}
	
	



}
