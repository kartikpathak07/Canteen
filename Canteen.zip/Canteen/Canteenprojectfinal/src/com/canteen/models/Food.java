package com.canteen.models;

public class Food {
	
	
	public String foodID;
	public String item_Name;
	public int item_Price;
	public String vendor_Id;
	public String category;
	public String vendor_name;
	public Food() {
		super();
		
	}
	
	
	public Food(String foodID, String item_Name, int item_Price,
			String vendor_Id, String category, String vendor_name) {
		super();
		this.foodID = foodID;
		this.item_Name = item_Name;
		this.item_Price = item_Price;
		this.vendor_Id = vendor_Id;
		this.category = category;
		this.vendor_name=vendor_name;
	}


	public String getVendor_name() {
		return vendor_name;
	}


	public void setVendor_name(String vendor_name) {
		this.vendor_name = vendor_name;
	}


	public String getFoodID() {
		return foodID;
	}
	public void setFoodID(String foodID) {
		this.foodID = foodID;
	}
	public String getItem_Name() {
		return item_Name;
	}
	public void setItem_Name(String item_Name) {
		this.item_Name = item_Name;
	}
	public int getItem_Price() {
		return item_Price;
	}
	public void setItem_Price(int item_Price) {
		this.item_Price = item_Price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}


	public String getVendor_Id() {
		return vendor_Id;
	}


	public void setVendor_Id(String vendor_Id) {
		this.vendor_Id = vendor_Id;
	}
	
	
	
}	