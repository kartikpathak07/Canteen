package com.canteen.models;

public class Cart {

	private String userName;
	private String item_Name;
	private int total_Cost;
	private String payment;
	
	public Cart() {
		super();
		
	}
	public Cart(String userName, String item_Name, int total_Cost,String payment) {
		super();
		this.userName = userName;
		this.item_Name = item_Name;
		this.total_Cost = total_Cost;
		this.payment=payment;
		
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getItem_Name() {
		return item_Name;
	}
	public void setItem_Name(String item_Name) {
		this.item_Name = item_Name;
	}
	public int getTotal_Cost() {
		return total_Cost;
	}
	public void setTotal_Cost(int total_Cost) {
		this.total_Cost = total_Cost;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	
	
}
