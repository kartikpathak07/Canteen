package com.canteen.daos;

import java.sql.Connection;

import com.canteen.models.Admin;



public interface AdminDAO {

	public Connection getConnection();
	public void closeConnection();
	public boolean addAdmin(Admin admin);
	public boolean updateAdmin(Admin admin);
	public boolean removeAdmin(String adminId);
	public Admin getAdmin(String adminName);
	public boolean validateAdmin(Admin admin);
	
	
}
