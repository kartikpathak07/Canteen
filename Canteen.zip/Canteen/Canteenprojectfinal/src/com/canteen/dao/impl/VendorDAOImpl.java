package com.canteen.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.canteen.daos.VendorDAO;
//import com.canteen.models.User;
import com.canteen.models.Vendor;

public class VendorDAOImpl implements VendorDAO{

	private Connection con;
	private String conURL="jdbc:oracle:thin:@localhost:1521:XE";
	private String dbUserName="system";
	private String dbPassword="system";
	private String driverClass="oracle.jdbc.OracleDriver";
	
	
	
	public VendorDAOImpl() {
		
		try {
			Class.forName(driverClass);
			System.out.println("++++++DRIVER LOADED +++++++++");
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
		
	}
	public VendorDAOImpl(String conURL,String dbUserName,String dbPassword,String driverClass){
		this.conURL=conURL;
		this.dbUserName=dbUserName;
		this.dbPassword=dbPassword;
		this.driverClass=driverClass;
		
			try {
				Class.forName(this.driverClass);
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			}
			System.out.println("++++++++ DRIVER LOADED +++++");
		}
		
	
	public Connection getConnection() {
		
		try {
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("++++++++ CONNECTION TO DB +++++++++");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return con;
	}


	public void closeConnection() {
		if(con!=null){
			try {
				con.close();
				System.out.println("++++++ CONNECTION TO DB CLOSED ++++++");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}


	public boolean addVendor(Vendor vendor) {
		String SQL="insert into vendor_tbl values(?,?,?,?,?,?,?)";
		boolean isAdded=false;
		getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, vendor.getFirstName());
			ps.setString(2, vendor.getLastName());
			ps.setString(3, vendor.getUserName());
			ps.setString(4, vendor.getPassword());
			ps.setString(5, vendor.getCellNo());
			ps.setString(6, vendor.getEmail());
			ps.setString(7, vendor.getVendor_name());
			
			
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isAdded=true;
				System.out.println("++++++++ VENDOR ADDED SUCCESSFULLY +++++++");
				
			}
		
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isAdded;
	}

	
	public boolean updateVendor(Vendor vendor) {
		String SQL="update vendor_tbl set firstname=?,"
				+ "lastname=?,password=?,"
				+ "cellno=?,email=?,vendor_name=?"
				+ " where username=?";
		boolean isUpdated=false;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, vendor.getFirstName());
			ps.setString(2, vendor.getLastName());
			ps.setString(3, vendor.getPassword());
			ps.setString(4, vendor.getCellNo());
			ps.setString(5, vendor.getEmail());
			ps.setString(6, vendor.getVendor_name());
			
			ps.setString(7, vendor.getUserName());
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isUpdated=true;
				System.out.println("++++++++  VENDOR UPDATED SUCCESSFULLY ++++++");
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isUpdated;
	}


	public boolean removeVendor(String userName) {
		
		String SQL="delete from vendor_tbl where username=?";
		boolean isRemoved=false;
		getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1,userName); //here only username is passed so not to use user.
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isRemoved=true;
				System.out.println("++++++ VENDOR DELETED SUCCESSFULLY ++++++");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isRemoved;
	}


	public Vendor getVendor(String userName) {
		String SQL="select * from vendor_tbl where userName=?";
		Vendor vendor=null;
		getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, userName);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				vendor=new Vendor();
				vendor.setFirstName(rs.getString("firstname"));
				vendor.setLastName(rs.getString("lastname"));
				vendor.setUserName(rs.getString("username"));
				vendor.setPassword(rs.getString("password"));
				vendor.setCellNo(rs.getString("cellno"));
				vendor.setEmail(rs.getString("email"));
				vendor.setVendor_name(rs.getString("vendor_name"));
				
	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return vendor;
	}
	
	public List<Vendor> getAllVendors() {
		String SQL="select * from vendor_tbl"; //unconditional retrieve
		ArrayList<Vendor>vendorList=new ArrayList<Vendor>();
		Vendor vendor=null;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				vendor=new Vendor();
				vendor.setFirstName(rs.getString("firstname"));
				vendor.setLastName(rs.getString("lastname"));
				vendor.setUserName(rs.getString("username"));
				vendor.setPassword(rs.getString("password"));
				vendor.setCellNo(rs.getString("cellno"));
				vendor.setEmail(rs.getString("email"));
				vendor.setVendor_name(rs.getString("vendor_name"));
				
	            vendorList.add(vendor);
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
	
		return vendorList;
	}


	public boolean validateVendor(Vendor vendor) {
		String SQL="select * from vendor_tbl where username=? and password=?";
		boolean isValid=false;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, vendor.getUserName());
			ps.setString(2, vendor.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				isValid=true;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return isValid;
	}
	/*public boolean provideLoginCredentials(Vendor vendor)
	{ boolean isAdded=false;
	int vid=0;
	getConnection();
	String sql="select * from vendor_tbl";
	try{
		PreparedStatement ps = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
	ResultSet rs=ps.executeQuery();
	if(rs.next()){
		rs.last();
	vid=rs.getInt("vendorId")+1;
	}else{
		vid=1;
		}
	vendor.setVendorId(vid);}
catch(SQLException e1){

e1.printStackTrace();}
		finally{
		closeConnection();
		}
	
		String SQL="update vendor_tbl set username,password =(?,?) where vendorId=? ";
		 isAdded=false;
		getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, vendor.getUserName());
			ps.setString(2,vendor.getPassword());
			ps.setInt(3, vendor.getVendorId());
			
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isAdded=true;
				
				System.out.println("++++++++ ID CREATED SUCCESSFULLY +++++++");
				
			}
		
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isAdded;
	}
	*/
	
	



}

	
		
		
		

	
	
	

