package com.canteen.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.canteen.dao.impl.VendorDAOImpl;
import com.canteen.daos.VendorDAO;
import com.canteen.models.Vendor;


public class AddVendorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private VendorDAO vendorDao;
	//private ServletContext ctx;
	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("++++++ init() Invoked +++++");
		vendorDao=new VendorDAOImpl();
		//ctx=config.getServletContext();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//String commonMsg=ctx.getInitParameter("commonMsg");
		//String commonMsg=ctx.getInitParameter("commonMessage");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String cellNo=request.getParameter("cellNo");
		String email=request.getParameter("email");
		String vendor_name=request.getParameter("vendor_name");
		
		Vendor vendor=new Vendor(firstName, lastName, userName, password, cellNo, email,vendor_name);
		boolean isAdded=vendorDao.addVendor(vendor);
		if(isAdded){
			RequestDispatcher rd=request.getRequestDispatcher("/registervendor.jsp");
			rd.forward(request, response);
			
		}
		else{
			response.sendRedirect("http://localhost:7001/Canteenproject/errorpage.html");
		}
			
	}
	
	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
