package com.canteen.servlets;

import java.io.IOException;
import java.io.PrintWriter;

//import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
//import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.canteen.dao.impl.VendorDAOImpl;

import com.canteen.daos.VendorDAO;

import com.canteen.models.Vendor;


public class vendor_add_byadmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private VendorDAO vendorDao;
	//private ServletContext ctx;
	
	public void init(ServletConfig config) throws ServletException {
		vendorDao=new VendorDAOImpl();
		//ctx=config.getServletContext();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("+++++++++++doget++++");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		//String commonMsg=ctx.getInitParameter("commonMsg");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String cellNo=request.getParameter("cellNo");
		String email=request.getParameter("email");
		String userName=request.getParameter("userName");
		
		Vendor vendor =new Vendor();
		vendor.setFirstName(firstName);
		vendor.setLastName(lastName);
		vendor.setCellNo(cellNo);
		vendor.setEmail(email);
		vendor.setUserName(userName);
		
		boolean isAdded=vendorDao.addVendor(vendor);
		if (isAdded){
		
			System.out.println("hello");
			out.println("<body bgcolor='pink'");
			out.println("<centre>");
			//out.println("<h1>"+commonMsg+"</h1>");
			out.println("<h3>Successfully Registered Vendor <I>"+userName+"</I></h3>");
			out.println("<h3><A href='homepage.jsp'>Login Now </A></h3>");
			out.println("</centre>");
			out.println("</body>");
			
			
		}else{
			out.println("<body bgcolor='pink'");
			out.println("<centre>");
			out.println("<h3>Error Registering User <I>"+userName+"</I></h3>");
			out.println("<h3><A href='homepage.jsp'>Register Again !! </A><h3>");
			out.println("</centre>");
			out.println("</body>");	
			
					
	}

	}


	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("++++doPost() Invoked");
		doGet(request, response);
	}

}
