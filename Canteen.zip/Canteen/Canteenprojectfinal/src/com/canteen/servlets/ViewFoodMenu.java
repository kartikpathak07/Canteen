package com.canteen.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.canteen.dao.impl.FoodDAOImpl;
import com.canteen.daos.FoodDAO;
import com.canteen.models.Food;
//import com.canteen.models.Vendor;


public class ViewFoodMenu extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private FoodDAO foodDao=new FoodDAOImpl();
	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init() invoked");
		foodDao=new FoodDAOImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		System.out.println("++++ doGet() ++++");
		response.setContentType("text/html");
		
		ArrayList<Food> foodList=new ArrayList<Food>();
		
		String vendor_name=request.getParameter("choices");
		
		foodList=(ArrayList<Food>)foodDao.getAllFood();
		HttpSession session=request.getSession();
		session.setAttribute(" foodList",  foodList);
		for(Food f : foodList){
			f.getFoodID(); 
			
		}
		request.setAttribute("foodList", foodList);
		if(foodList.size()>0){
			RequestDispatcher rd=request.getRequestDispatcher("/viewFoodMenu.jsp");
			rd.forward(request, response);
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
