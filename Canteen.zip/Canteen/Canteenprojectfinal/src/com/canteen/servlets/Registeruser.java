package com.canteen.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
//import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.canteen.dao.impl.UserDAOImpl;
import com.canteen.daos.UserDAO;
import com.canteen.models.User;

 
public class Registeruser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDAO userDao;
	//private ServletContext ctx;
	
	public void init(ServletConfig config) throws ServletException {
		userDao=new UserDAOImpl();
		//ctx=config.getServletContext();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("+++++++++++doget++++");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//String commonMsg=ctx.getInitParameter("commonMsg");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String cellNo=request.getParameter("cellNo");
		String email=request.getParameter("email");
		int age=Integer.parseInt(request.getParameter("age"));
		User user=new User(firstName,lastName,userName,password,cellNo,email,age);
		boolean isAdded=userDao.addUser(user);
		if(isAdded){
			out.println("<body bgcolor='pink'");
			out.println("<centre>");
			out.println("<h1>Online Canteen Application</h1>");
			out.println("<h3>Successfully Registered User <I>"+userName+"</I></h3>");
			out.println("<h3><A href='welcome.jsp'>Login Now </A></h3>");
			out.println("</centre>");
			out.println("</body>");
		}else{
			out.println("<body bgcolor='pink'");
			out.println("<centre>");
			out.println("<h3>Error Registering User <I>"+userName+"</I></h3>");
			out.println("<h3><A href='welcome.jsp'>Login Now </A><h3>");
			out.println("</centre>");
			out.println("</body>");	
	}

}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("+++++++++doPost()INVOKED++++++++++");
		doGet(request,response);

}

}