package com.canteen.servlets;

import java.io.IOException;
import java.io.PrintWriter;

//import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.canteen.dao.impl.VendorDAOImpl;
import com.canteen.daos.VendorDAO;


public class RemoveVendor extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private VendorDAO vendorDao;
	
	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("++++Init() Invoked ++++");
		vendorDao =new VendorDAOImpl();
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String userName=request.getParameter("userName");
		boolean isRemoved=vendorDao.removeVendor(userName);
		//ps.setString(1,userName);
		if(isRemoved){
			System.out.println("if");
			out.println("<h3>Successfully Deleted Vendor</h3>");
			//RequestDispatcher rd=request.getRequestDispatcher("/removeVendor.jsp");
			//rd.forward(request, response);
		}
		else{
			System.out.println("else");
			response.sendRedirect("http://localhost:7001/Canteenproject/errorpage.html");
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
