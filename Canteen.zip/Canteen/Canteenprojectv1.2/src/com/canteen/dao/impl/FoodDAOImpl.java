package com.canteen.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.canteen.daos.FoodDAO;
import com.canteen.models.Food;

public class FoodDAOImpl implements FoodDAO {

	private Connection con;
	private String conURL="jdbc:oracle:thin:@localhost:1521:XE";
	private String dbUserName="system";
	private String dbPassword="system";
	private String driverClass="oracle.jdbc.OracleDriver";
	
	public FoodDAOImpl(){}
	
	public FoodDAOImpl(String conURL,String dbUserName,String dbPassword,String driverClass){
	
		this.conURL=conURL;
		this.dbUserName=dbUserName;
		this.dbPassword=dbPassword;
		this.driverClass=driverClass;
		
			try {
				Class.forName(this.driverClass);
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			}
			System.out.println("++++++++ DRIVER LOADED +++++");
		}
		
	
	public Connection getConnection() {
		
		try {
			con=DriverManager.getConnection(conURL,dbUserName,dbPassword);
			System.out.println("++++++++ CONNECTION TO DB +++++++++");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return con;
	}

	
	public void closeConnection() {
		if(con!=null){
			try {
				con.close();
				System.out.println("++++++ CONNECTION TO DB CLOSED ++++++");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	
	public boolean addFood(Food food) {
		String SQL="insert into food_tbl values(?,?,?,?,?,?)";
		boolean isAdded=false;
		getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1,food.getFoodID());
			ps.setString(2, food.getItem_Name());
			ps.setInt(3, food.getItem_Price());
			
			ps.setString(4,food.getVendor_Id());
			ps.setString(5, food.getCategory());
			ps.setString(6, food.getVendor_name());
			
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isAdded=true;
				System.out.println("++++++++ FOOD ADDED SUCCESSFULLY +++++++");
				
			}
		
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isAdded;
	}

	
	public boolean removeFood(int foodID) {
		String SQL="delete from food_tbl where foodID=?";
		boolean isRemoved=false;
		getConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setInt(1, foodID); //here only username is passed so not to use user.
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isRemoved=true;
				System.out.println("++++++ FOOD DELETED SUCCESSFULLY ++++++");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isRemoved;
	
	
	}

	
	public boolean updateFood(Food food) {
		String SQL="update food_tbl set item_Name =?,"
				+ "item_Price=?,vendor_Id=?,category=?,vendor_name=?"
				+ " where foodID=?";
		boolean isUpdated=false;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, food.getItem_Name());
			ps.setInt(2, food.getItem_Price());
			ps.setString(3, food.getVendor_Id());
			ps.setString(4, food.getCategory());
			ps.setString(5, food.getVendor_name());
			ps.setString(6, food.getFoodID());
			
			
			int cnt=ps.executeUpdate();
			if(cnt==1){
				isUpdated=true;
				System.out.println("++++++++  FOOD UPDATED SUCCESSFULLY ++++++");
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			closeConnection();
		}
		
		return isUpdated;
	}

	public List<Food> getAllFood() {
		ArrayList<Food> foodList=new ArrayList<Food>();
		String SQL="select * from food_tbl";
		Food food=null;
		getConnection();
		try {
			PreparedStatement ps=con.prepareStatement(SQL);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				food=new Food();
				food.setFoodID(rs.getString("foodID"));
				food.setItem_Name(rs.getString("item_name"));
				food.setItem_Price(rs.getInt("item_price"));
				food.setVendor_Id(rs.getString("vendor_Id"));
				food.setCategory(rs.getString("category"));
				food.setVendor_name(rs.getString("vendor_name"));
	            foodList.add(food);
			}
		}
			catch(SQLException e){
				e.printStackTrace();
			}finally{
				closeConnection();
			}
			return foodList;
	}
	
	public List<Food> getAllFoodByVendorName(String vendor_name){
		ArrayList<Food> foodList=new ArrayList<Food>();
		String SQL="select * from food_tbl where vendor_name= ? ";
		Food food=null;
		getConnection();
		try {
			//System.out.println("+++vendor_name+"+vendor_name);
			PreparedStatement ps=con.prepareStatement(SQL);
			ps.clearParameters();
			ps.setString(1, vendor_name);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				food=new Food();
				food.setFoodID(rs.getString("foodID"));
				food.setItem_Name(rs.getString("item_name"));
				food.setItem_Price(rs.getInt("item_price"));
				food.setVendor_Id(rs.getString("vendor_Id"));
				food.setCategory(rs.getString("category"));		
				food.setVendor_name(rs.getString("vendor_name"));
	            foodList.add(food);
			}
		}
			catch(SQLException e){
				e.printStackTrace();
			}finally{
				closeConnection();
			}
			return foodList;
	}
		
}
