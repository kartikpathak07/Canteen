package com.canteen.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.canteen.dao.impl.AdminDAOImpl;
import com.canteen.dao.impl.UserDAOImpl;
import com.canteen.dao.impl.VendorDAOImpl;
import com.canteen.daos.AdminDAO;
import com.canteen.daos.UserDAO;
import com.canteen.daos.VendorDAO;
import com.canteen.models.Admin;
import com.canteen.models.User;
import com.canteen.models.Vendor;


public class LoginServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private UserDAO userDao=new UserDAOImpl();
	private AdminDAO adminDao=new AdminDAOImpl();
	private VendorDAO vendorDao=new VendorDAOImpl();
	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("+++++ Init() Invoked +++++");
		
		//ctx=config.getServletContext();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		session.getMaxInactiveInterval();
		System.out.println("SESSION ID : :" +session.getId());
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//String userName=request.getParameter("userName");
		//System.out.println(userName);
		//String password=request.getParameter("password");
		//session.setAttribute("username", userName);
		String choice=request.getParameter("choice");
		System.out.println(choice);
		if(choice.equals("Admin"))
		{
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			
			Admin admin=new Admin();
			admin.setUserName(userName);
			admin.setPassword(password);
			
			boolean isValid=adminDao.validateAdmin(admin);
			if(isValid)
			{
				out.println("<h4>Admin Working</h4>");
				//session.setAttribute("sessAdmin", admin.getUserName());
				RequestDispatcher rd=request.getRequestDispatcher("/AdminList.jsp");
				rd.forward(request, response);
			}
			else
			{
				response.sendRedirect("http://localhost:7001/Canteenproject/errorpage.html");
				
			}
		}
		else if(choice.equals("Vendor"))
		{
			
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			
			Vendor vendor=new Vendor();
			vendor.setUserName(userName);
			vendor.setPassword(password);
			
			boolean isValid=vendorDao.validateVendor(vendor);
			if(isValid)
			{
			out.println("<h4>Vendor Working</h4>");
			//session.setAttribute("sessVendor", "vendor");
			RequestDispatcher rd=request.getRequestDispatcher("/ViewFoodMenu.jsp");
			rd.forward(request, response);
		}else
		{
			response.sendRedirect("http://localhost:7001/Canteenproject/errorpage.html");
			
		}
	      }
		else if(choice.equals("user")){
			
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			session.setAttribute("userName", userName);
			User user=new User();
			user.setUserName(userName);
			user.setPassword(password);
			System.out.println(user.getUserName());
			
			boolean isValid=userDao.validateUser(user);
			if(isValid){
			out.println("<h4>User Working</h4>");
			//session.setAttribute("sessUser", "user");
			RequestDispatcher rd=request.getRequestDispatcher("/Userpage.jsp");
			rd.forward(request, response);
		}else
		{
			response.sendRedirect("http://localhost:7001/Canteenproject/errorpage.html");
		}
	}	

		
		
}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
