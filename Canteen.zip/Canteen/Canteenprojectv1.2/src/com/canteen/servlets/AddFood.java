package com.canteen.servlets;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.canteen.dao.impl.FoodDAOImpl;
import com.canteen.daos.FoodDAO;


public class AddFood extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private FoodDAO foodDao;
	
	public void init(ServletConfig config) throws ServletException {
		foodDao=new FoodDAOImpl();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String foodID=request.getParameter("foodID");
		String item_Name=request.getParameter("item_Name");
		String item_Price=request.getParameter("item_Price");
		String vendor_Id=request.getParameter("vendor_Id");
		String category=request.getParameter("category");
		String vendor_name=request.getParameter("vendor_name");
		
		AddFood addfood=new AddFood();
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
